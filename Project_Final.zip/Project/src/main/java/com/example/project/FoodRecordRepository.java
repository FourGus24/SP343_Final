package com.example.project;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodRecordRepository extends MongoRepository<FoodRecord, String> {
    List<FoodRecord> findByDateOrderByIdAsc(String date);
    // เพิ่มเมธอดสำหรับค้นหาข้อมูลตามวันที่
    List<FoodRecord> findByDate(String date);
    // เพิ่มเมธอดสำหรับค้นหาข้อมูลตาม userId
    List<FoodRecord> findByUserId(String userId);
    // เพิ่มเมธอดสำหรับค้นหาข้อมูลตาม userId และ date
    List<FoodRecord> findByUserIdAndDate(String userId, String date);
    // เพิ่มเมธอดสำหรับค้นหาข้อมูลตาม userId และเรียงตามวันที่จากล่าสุดไปเก่าสุด
    List<FoodRecord> findByUserIdOrderByDateDesc(String userId);
}