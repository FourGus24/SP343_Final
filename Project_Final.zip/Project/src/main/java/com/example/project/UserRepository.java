package com.example.project;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends MongoRepository<User, String> {
    // ค้นหาผู้ใช้ตาม username
    User findByUsername(String username);
    // ค้นหาผู้ใช้ตาม email
    User findByEmail(String email);
    // ตรวจสอบว่ามี username นี้ในระบบหรือไม่
    boolean existsByUsername(String username);
    // ตรวจสอบว่ามี email นี้ในระบบหรือไม่
    boolean existsByEmail(String email);
}