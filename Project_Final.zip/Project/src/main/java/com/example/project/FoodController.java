package com.example.project;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;
import java.util.stream.Collectors;

 // คลาส Controller สำหรับจัดการเกี่ยวกับอาหาร ผู้ใช้ และการบันทึกข้อมูลโภชนาการ
@Controller
public class FoodController {
    @Autowired
    private FoodRepository foodRepository;
    @Autowired
    private FoodRecordRepository foodRecordRepository;
    @Autowired
    private UserRepository userRepository;

     //แสดงหน้าหลัก
    @GetMapping("/")
    public String homePage(Model model, HttpSession session) {
        model.addAttribute("username", session.getAttribute("username"));
        return "index";
    }
     //แสดงหน้าเข้าสู่ระบบ
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }
     //แสดงหน้าสมัครสมาชิก
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }
    //แสดงหน้ารายการอาหาร
    @GetMapping("/menu")
    public String menuPage(Model model, @RequestParam(required = false) String foodId, HttpSession session) {
        model.addAttribute("username", session.getAttribute("username"));
        List<Food> foodList = foodRepository.findAll();
        model.addAttribute("foodList", foodList);
        // ถ้ามีการส่ง foodId มา ให้ค้นหาข้อมูลอาหารนั้นๆ
        if (foodId != null && !foodId.isEmpty()) {
            foodRepository.findById(foodId).ifPresent(food -> {
                model.addAttribute("selectedFood", food);
                model.addAttribute("showFoodDetail", true);
            });
        }
        return "menu";
    }
     //แสดงหน้าบันทึกอาหาร / แสดงประวัติการบันทึกอาหารของผู้ใช้ที่ล็อกอินอยู่
    @GetMapping("/record")
    public String recordPage(Model model, HttpSession session) {
        model.addAttribute("username", session.getAttribute("username"));
        // ตรวจสอบว่ามีการล็อกอินหรือไม่
        if (session.getAttribute("userId") == null) {
            model.addAttribute("notLoggedIn", true);
            return "record";
        }
        String userId = (String) session.getAttribute("userId");
        List<FoodRecord> userRecords = foodRecordRepository.findByUserId(userId);
        // ถ้าไม่มีข้อมูลบันทึกอาหาร
        if (userRecords.isEmpty()) {
            model.addAttribute("foodRecordsByDate", null);
            return "record";
        }
        // จัดกลุ่มข้อมูลตามวันที่ (เรียงจากวันล่าสุด)
        Map<String, List<FoodRecord>> foodRecordsByDate = groupRecordsByDate(userRecords);
        // คำนวณยอดรวมสำหรับแต่ละวัน
        Map<String, Map<String, String>> totals = calculateDailyTotals(foodRecordsByDate);
        model.addAttribute("foodRecordsByDate", foodRecordsByDate);
        model.addAttribute("totals", totals);
        return "record";
    }
     //แสดงหน้าเพิ่มอาหาร / สำหรับบันทึกรายการอาหารที่รับประทานไป
    @GetMapping("/food")
    public String foodPage(Model model, HttpSession session) {
        // ตรวจสอบว่ามีการล็อกอินหรือไม่
        if (session.getAttribute("userId") == null) {
            return "redirect:/login";
        }
        model.addAttribute("username", session.getAttribute("username"));
        List<Food> foodList = foodRepository.findAll();
        model.addAttribute("foodList", foodList);
        return "food";
    }
     //แสดงหน้าข้อมูลผู้ใช้ / แสดงข้อมูลส่วนตัวและค่า BMI,BMR ของผู้ใช้
    @GetMapping("/user")
    public String userPage(Model model, HttpSession session) {
        model.addAttribute("username", session.getAttribute("username"));
        // ตรวจสอบว่ามีการล็อกอินหรือไม่
        if (session.getAttribute("userId") == null) {
            return "redirect:/login";
        }
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser != null) {
            model.addAttribute("user", currentUser);
            // คำนวณอายุ BMI และ BMR
            int calculatedAge = currentUser.calculateAge();
            double bmi = currentUser.calculateBMI();
            double bmr = currentUser.calculateBMR();

            model.addAttribute("calculatedAge", calculatedAge);
            model.addAttribute("bmi", String.format("%.2f", bmi));
            model.addAttribute("bmr", String.format("%.0f", bmr));
            model.addAttribute("bmiStatus", getBmiStatus(bmi));
        }
        return "user";
    }
     //เช็คการล็อกอิน / ตรวจสอบข้อมูลผู้ใช้
    @PostMapping("/login")
    public String processLogin(@RequestParam String username, @RequestParam String password,
                               HttpSession session, RedirectAttributes redirectAttributes) {
        User user = userRepository.findByUsername(username);

        if (user != null && user.getPassword().equals(password)) {
            // ล็อกอินสำเร็จ
            session.setAttribute("currentUser", user);
            session.setAttribute("userId", user.getId());
            session.setAttribute("username", user.getUsername());
            return "redirect:/";
        } else {
            // ล็อกอินล้มเหลว
            redirectAttributes.addFlashAttribute("errorMessage",
                    (user == null) ? "ไม่พบบัญชีผู้ใช้นี้ในระบบ" : "รหัสผ่านไม่ถูกต้อง");
            return "redirect:/login";
        }
    }
     //ออกจากระบบ (Logout)
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
     //เช็คการสมัครสมาชิก / รับข้อมูลที่ผู้ใช้งานกรอกข้อมูลแล้วบีนทึกข้อมูล
    @PostMapping("/register")
    public String processRegistration(@RequestParam Map<String, String> formData) {
        try {
            // ตรวจสอบว่า username หรือ email ซ้ำหรือไม่
            String username = formData.get("username");
            String email = formData.get("email");

            if (userRepository.existsByUsername(username)) {
                return "redirect:/register?error=username_exists";
            }

            if (userRepository.existsByEmail(email)) {
                return "redirect:/register?error=email_exists";
            }

            // ตรวจสอบว่ารหัสผ่านตรงกันหรือไม่
            String password = formData.get("password");
            String confirmPassword = formData.get("confirmPassword");

            if (!password.equals(confirmPassword)) {
                return "redirect:/register?error=password_mismatch";
            }

            // สร้างอ็อบเจ็กต์ User ใหม่
            User newUser = createUserFromFormData(formData);
            userRepository.save(newUser);

            return "redirect:/login?registered=true";

        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/register?error=invalid_data";
        }
    }
     //อัปเดตข้อมูลผู้ใช้ อัปเดตข้อมูลเช่น น้ำหนัก ส่วนสูง วันเกิด และเป้าหมาย
    @PostMapping("/api/update-user")
    @ResponseBody
    public ResponseEntity<?> updateUser(@RequestParam Map<String, String> formData, HttpSession session) {
        try {
            // ตรวจสอบว่ามีการล็อกอินหรือไม่
            if (session.getAttribute("userId") == null) {
                return ResponseEntity.status(401).body(Map.of(
                        "success", false,
                        "message", "กรุณาล็อกอินก่อนแก้ไขข้อมูล"
                ));
            }
            String userId = (String) session.getAttribute("userId");
            User user = userRepository.findById(userId).orElse(null);

            if (user == null) {
                return ResponseEntity.status(404).body(Map.of(
                        "success", false,
                        "message", "ไม่พบข้อมูลผู้ใช้"
                ));
            }
            // อัปเดตข้อมูลผู้ใช้
            boolean updateSuccessful = updateUserProperties(user, formData);
            if (!updateSuccessful) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "message", "ข้อมูลไม่ถูกต้อง"
                ));
            }
            // บันทึกข้อมูลที่อัปเดต
            userRepository.save(user);
            session.setAttribute("currentUser", user);

            // คำนวณค่าต่างๆ ใหม่
            double bmi = user.calculateBMI();
            double bmr = user.calculateBMR();
            int calculatedAge = user.calculateAge();
            String bmiStatus = getBmiStatus(bmi);

            // สร้าง Map สำหรับส่งข้อมูลกลับ
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("bmi", String.format("%.2f", bmi));
            response.put("bmr", String.format("%.0f", bmr));
            response.put("bmiStatus", bmiStatus);
            response.put("calculatedAge", calculatedAge);

            return ResponseEntity.ok(response);
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "รูปแบบข้อมูลไม่ถูกต้อง: " + e.getMessage()
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "message", "เกิดข้อผิดพลาด: " + e.getMessage()
            ));
        }
    }
     //ตรวจสอบว่าชื่อผู้ใช้มีอยู่แล้วหรือไม่
    @GetMapping("/api/check-username")
    @ResponseBody
    public Map<String, Boolean> checkUsernameExists(@RequestParam String username) {
        boolean exists = userRepository.existsByUsername(username);
        return Map.of("exists", exists);
    }
     //ตรวจสอบว่าอีเมลมีอยู่แล้วหรือไม่
    @GetMapping("/api/check-email")
    @ResponseBody
    public Map<String, Boolean> checkEmailExists(@RequestParam String email) {
        boolean exists = userRepository.existsByEmail(email);
        return Map.of("exists", exists);
    }
     //ดึงข้อมูลอาหารทั้งหมด
    @GetMapping("/api/foods")
    @ResponseBody
    public List<Food> getAllFoods() {
        return foodRepository.findAll();
    }
     //ดึงข้อมูลอาหารตามไอดี
    @GetMapping("/api/foods/{id}")
    @ResponseBody
    public Food getFoodById(@PathVariable String id) {
        return foodRepository.findById(id).orElse(null);
    }
     //ค้นหาอาหารตามชื่อ
    @GetMapping("/api/foods/search")
    @ResponseBody
    public List<Food> searchFoods(@RequestParam String query) {
        if (query == null || query.trim().isEmpty()) {
            return new ArrayList<>();
        }

        List<Food> allFoods = foodRepository.findAll();
        return allFoods.stream()
                .filter(food -> food.getTitle().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());
    }
     // บันทึกข้อมูลการรับประทานอาหาร
    @PostMapping("/api/food-records")
    @ResponseBody
    public ResponseEntity<?> saveFoodRecords(@RequestBody Map<String, Object> requestData, HttpSession session) {
        try {
            // ตรวจสอบว่ามีการล็อกอินหรือไม่
            if (session.getAttribute("userId") == null) {
                return ResponseEntity.status(401).body("กรุณาล็อกอินก่อนบันทึกข้อมูล");
            }

            String userId = (String) session.getAttribute("userId");
            String date = (String) requestData.get("date");
            List<Map<String, Object>> entries = (List<Map<String, Object>>) requestData.get("entries");

            if (date == null || entries == null || entries.isEmpty()) {
                return ResponseEntity.badRequest().body("Missing required data");
            }

            for (Map<String, Object> entry : entries) {
                saveFoodRecord(userId, date, entry);
            }

            return ResponseEntity.ok().build();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
     // API ลบข้อมูลอาหารตามวันที่
    @PostMapping("/api/food-records/delete-by-date")
    @ResponseBody
    public ResponseEntity<?> deleteFoodRecordsByDate(@RequestBody Map<String, String> requestData, HttpSession session) {
        try {
            // ตรวจสอบว่ามีการล็อกอินหรือไม่
            if (session.getAttribute("userId") == null) {
                return ResponseEntity.status(401).body("กรุณาล็อกอินก่อนลบข้อมูล");
            }
            String userId = (String) session.getAttribute("userId");
            String date = requestData.get("date");
            if (date == null || date.isEmpty()) {
                return ResponseEntity.badRequest().body("กรุณาระบุวันที่");
            }
            // ค้นหาข้อมูลอาหารตามวันที่และ userId
            List<FoodRecord> records = foodRecordRepository.findByUserIdAndDate(userId, date);
            if (records.isEmpty()) {
                return ResponseEntity.ok().body("ไม่พบข้อมูลในวันที่ระบุ");
            }
            // ลบข้อมูลทั้งหมด
            foodRecordRepository.deleteAll(records);

            return ResponseEntity.ok().body("ลบข้อมูลเรียบร้อยแล้ว");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
     //เพิ่มข้อมูลอาหารใหม่ (สำหรับทดสอบเท่านั้น)
    @PostMapping("/api/test/add-food")
    @ResponseBody
    public ResponseEntity<?> addFoodTest(@RequestBody Food newFood) {
        try {
            // ตรวจสอบข้อมูลที่จำเป็น
            if (newFood.getTitle() == null || newFood.getTitle().trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "message", "กรุณาระบุชื่ออาหาร"
                ));
            }
            // กำหนดค่าเริ่มต้นถ้าไม่ได้ระบุ
            if (newFood.getAmount() == null || newFood.getAmount().trim().isEmpty()) {
                newFood.setAmount("1 จาน");
            }
            // บันทึกอาหารใหม่
            Food savedFood = foodRepository.save(newFood);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "เพิ่มรายการอาหารสำเร็จ",
                    "food", savedFood
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "message", "เกิดข้อผิดพลาด: " + e.getMessage()
            ));
        }
    }
     //จัดเรียงข้อมูลที่บันทึกอาหาร
    private Map<String, List<FoodRecord>> groupRecordsByDate(List<FoodRecord> records) {
        Map<String, List<FoodRecord>> recordsByDate = new TreeMap<>(Collections.reverseOrder());

        for (FoodRecord record : records) {
            String date = record.getDate();
            if (!recordsByDate.containsKey(date)) {
                recordsByDate.put(date, new ArrayList<>());
            }
            recordsByDate.get(date).add(record);
        }

        return recordsByDate;
    }
     //คำนวณยอดรวมของโภชนาการอาหาร
    private Map<String, Map<String, String>> calculateDailyTotals(Map<String, List<FoodRecord>> recordsByDate) {
        Map<String, Map<String, String>> totals = new HashMap<>();

        for (Map.Entry<String, List<FoodRecord>> entry : recordsByDate.entrySet()) {
            String date = entry.getKey();
            List<FoodRecord> records = entry.getValue();

            double totalCalories = 0;
            double totalProtein = 0;
            double totalCarbs = 0;
            double totalFat = 0;

            for (FoodRecord record : records) {
                if (record.getCalories() != null && !record.getCalories().equals("-"))
                    totalCalories += Double.parseDouble(record.getCalories());
                if (record.getProtein() != null && !record.getProtein().equals("-"))
                    totalProtein += Double.parseDouble(record.getProtein());
                if (record.getCarbs() != null && !record.getCarbs().equals("-"))
                    totalCarbs += Double.parseDouble(record.getCarbs());
                if (record.getFat() != null && !record.getFat().equals("-"))
                    totalFat += Double.parseDouble(record.getFat());
            }

            Map<String, String> dailyTotal = new HashMap<>();
            dailyTotal.put("calories", String.format("%.1f", totalCalories));
            dailyTotal.put("protein", String.format("%.1f", totalProtein));
            dailyTotal.put("carbs", String.format("%.1f", totalCarbs));
            dailyTotal.put("fat", String.format("%.1f", totalFat));

            totals.put(date, dailyTotal);
        }

        return totals;
    }
     //บันทึกข้อมูลการรับประทานอาหาร
    private void saveFoodRecord(String userId, String date, Map<String, Object> entry) {
        FoodRecord record = new FoodRecord();
        record.setUserId(userId);
        record.setDate(date);
        record.setFoodId((String) entry.get("foodId"));
        record.setFoodName((String) entry.get("foodName"));
        record.setQuantity((String) entry.get("quantity"));
        record.setCalories((String) entry.get("calories"));
        record.setProtein((String) entry.get("protein"));
        record.setCarbs((String) entry.get("carbs"));
        record.setFat((String) entry.get("cholesterol"));
        foodRecordRepository.save(record);
    }

    private User createUserFromFormData(Map<String, String> formData) {
        User newUser = new User();
        newUser.setUsername(formData.get("username"));
        newUser.setEmail(formData.get("email"));
        newUser.setPassword(formData.get("password"));
        newUser.setDateOfBirth(formData.get("dateOfBirth"));
        newUser.setGender(formData.get("gender"));
        newUser.setWeight(Double.parseDouble(formData.get("weight")));
        newUser.setHeight(Double.parseDouble(formData.get("height")));
        newUser.setGoal(formData.get("goal"));
        return newUser;
    }
     //อัปเดตคุณสมบัติของผู้ใช้ อัพเดตสำเร็จ true ถ้าอัปเดตสำเร็จ, false ถ้าข้อมูลไม่ถูกต้อง
    private boolean updateUserProperties(User user, Map<String, String> formData) {
        if (formData.containsKey("weight")) {
            double weight = Double.parseDouble(formData.get("weight"));
            if (weight <= 0) return false;
            user.setWeight(weight);
        }

        if (formData.containsKey("height")) {
            double height = Double.parseDouble(formData.get("height"));
            if (height <= 0) return false;
            user.setHeight(height);
        }

        if (formData.containsKey("dateOfBirth")) {
            String dateOfBirth = formData.get("dateOfBirth");
            if (dateOfBirth == null || dateOfBirth.isEmpty()) return false;
            user.setDateOfBirth(dateOfBirth);
        }

        if (formData.containsKey("goal")) {
            user.setGoal(formData.get("goal"));
        }
        return true;
    }
     //ค่าสถานะ BMI
    private String getBmiStatus(double bmi) {
        if (bmi < 18.5) return "ผอม";
        if (bmi < 25) return "ปกติ";
        if (bmi < 30) return "น้ำหนักเกิน";
        return "อ้วน";
    }
}