package com.example.project;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Document(collection = "User")
public class User {
    @Id
    private String id;
    private String username;
    private String email;
    private String password;
    private String dateOfBirth; //เก็บในรูปแบบ YYYY-MM-DD
    private String gender;
    private double weight;
    private double height;
    private String goal;
    private boolean admin = false;

    public User() {
    }
    public User(String username, String email, String password, String dateOfBirth,
                String gender, double weight, double height, String goal) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.weight = weight;
        this.height = height;
        this.goal = goal;
    }

    public User(String username, String email, String password, int age,
                String gender, double weight, double height, String goal) {
        this.username = username;
        this.email = email;
        this.password = password;
        // แปลงจากอายุเป็นวันเกิดโดยประมาณ (ลบอายุจากปีปัจจุบัน)
        LocalDate approximateBirthDate = LocalDate.now().minusYears(age);
        this.dateOfBirth = approximateBirthDate.format(DateTimeFormatter.ISO_DATE);
        this.gender = gender;
        this.weight = weight;
        this.height = height;
        this.goal = goal;
    }

    //คำนวณอายุ
    public int calculateAge() {
        if (dateOfBirth == null || dateOfBirth.isEmpty()) {
            return 0;
        }

        try {
            LocalDate birthDate = LocalDate.parse(dateOfBirth);
            LocalDate currentDate = LocalDate.now();
            return Period.between(birthDate, currentDate).getYears();
        } catch (DateTimeParseException e) {
            System.err.println("ไม่สามารถแปลงวันเกิดได้: " + e.getMessage());
            return 0;
        }
    }

    //ค่า BMI
    public double calculateBMI() {
        if (height <= 0) return 0;
        double heightInMeters = height / 100.0; // แปลงส่วนสูงจากเซนติเมตรเป็นเมตร
        return weight / (heightInMeters * heightInMeters);
    }

    //ค่า BMR
    public double calculateBMR() {
        int age = calculateAge();

        if (gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("ชาย")) {
            // สูตรสำหรับผู้ชาย
            return 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
        } else {
            // สูตรสำหรับผู้หญิง
            return 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
        }
    }

     //วันเกิด (DD/MM/YYYY)
    public String getFormattedDateOfBirth() {
        if (dateOfBirth == null || dateOfBirth.isEmpty()) {
            return "-";
        }

        try {
            LocalDate birthDate = LocalDate.parse(dateOfBirth);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return birthDate.format(formatter);
        } catch (DateTimeParseException e) {
            return "-";
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public int getAge() {
        return calculateAge();
    }

    public void setAge(int age) {
        LocalDate approximateBirthDate = LocalDate.now().minusYears(age);
        this.dateOfBirth = approximateBirthDate.format(DateTimeFormatter.ISO_DATE);
    }
}